package com.ideas2it.controller;

import com.ideas2it.model.Employee;
import com.ideas2it.model.Trainee;
import com.ideas2it.model.Trainer;
import com.ideas2it.service.UserService;
import com.ideas2it.service.impl.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.jws.WebParam;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import java.util.ArrayList;
import java.util.List;

@Controller
public class AddController {
    @Autowired
    UserService userService;



    @RequestMapping(value = "/trainerRegister",method = RequestMethod.GET)
    public ModelAndView showRegister(HttpServletRequest request, HttpServletResponse response) {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("register");
        mav.addObject("trainer",new Trainer());
        return mav;
    }

    @RequestMapping(value = "/traineeRegister",method = RequestMethod.GET)
    public ModelAndView showRegistert(HttpServletRequest request, HttpServletResponse response) {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("Traineeregister");
        mav.addObject("trainee",new Trainee());
        return mav;
    }

    @RequestMapping(value = "/DisplayTrainerById",method = RequestMethod.GET)
    public ModelAndView displayTrainerByID(HttpServletRequest request, HttpServletResponse response) {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("getTrainerId");
        return mav;
    }

    @RequestMapping(value = "/DisplayTraineeById",method = RequestMethod.GET)
    public ModelAndView displayTraineeByID(HttpServletRequest request, HttpServletResponse response) {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("getTraineeId");
        return mav;
    }



    @RequestMapping(value = "/updateTrainer",method = RequestMethod.GET)
    public ModelAndView updateTrainer(HttpServletRequest request, HttpServletResponse response) {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("viewById");
        mav.addObject("trainer",new Trainer());
        return mav;
    }
    @RequestMapping(value = "/updateTrainee",method = RequestMethod.GET)
    public ModelAndView updateTrainee(HttpServletRequest request, HttpServletResponse response) {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("TraineeUpdate");
        mav.addObject("trainee",new Trainee());
        return mav;
    }

    @PostMapping(value = "/trainerUpdate")
    public ModelAndView  updateTrainer(HttpServletRequest request, HttpServletResponse response,@ModelAttribute("trainer") Trainer user) {
        ModelAndView mav = new ModelAndView();
        userService.update(user);
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("welcome");
        return modelAndView;
    }

    @PostMapping("/traineeUpdate")
    public ModelAndView updateTrainee(HttpServletRequest request, HttpServletResponse response,@ModelAttribute("trainee") Trainee user) {
        ModelAndView mav = new ModelAndView();
        userService.update(user);
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("welcome");
        return modelAndView;
    }

    @PostMapping( "/registerProcess")
    public ModelAndView get(HttpServletRequest request, HttpServletResponse response, @ModelAttribute("trainer")Trainer employee) {
        userService.register(employee);
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("welcome");
        return modelAndView;
    }

    @PostMapping("/trainee")
    public ModelAndView gettrainer(HttpServletRequest request, HttpServletResponse response, @ModelAttribute("trainee")Trainee employee) {
        userService.register(employee);
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("welcome");
        return modelAndView;
    }


    @RequestMapping(value="/viewTrainer")
    public String viewTrainer(Model user){
        List<Employee> list=userService.getTrainers();
        user.addAttribute("list",list);
        return "viewemp";
    }

    @RequestMapping(value="/viewTrainee")
    public String viewTrainee(Model user){
        List<Employee> list=userService.getTrainees();
        user.addAttribute("list",list);
        return "viewemp";
    }

    @GetMapping("/trainerId")
    public ModelAndView viewTrainerById(HttpServletRequest request, HttpServletResponse response){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("falseDisplay");
        Trainer id = userService.getTrainerById(request.getParameter("employeeId"));
        modelAndView.addObject("employeeId",id.getEmployeeId());
        modelAndView.addObject("employeeFirstName",id.getEmployeeFirstName());
        modelAndView.addObject("employeeLastName",id.getEmployeeLastName());
        modelAndView.addObject("employeePhoneNumber",id.getEmployeePhoneNumber());
        return  modelAndView;
    }
    @GetMapping("/traineeId")
    public ModelAndView viewTraineeById(HttpServletRequest request, HttpServletResponse response){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("falseDisplay");
        Trainee id = userService.getTraineeById(request.getParameter("employeeId"));
        modelAndView.addObject("employeeId",id.getEmployeeId());
        modelAndView.addObject("employeeFirstName",id.getEmployeeFirstName());
        modelAndView.addObject("employeeLastName",id.getEmployeeLastName());
        modelAndView.addObject("employeePhoneNumber",id.getEmployeePhoneNumber());
        return  modelAndView;
    }

}
