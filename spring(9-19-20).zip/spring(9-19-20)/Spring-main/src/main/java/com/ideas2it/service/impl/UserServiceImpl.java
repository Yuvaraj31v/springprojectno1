package com.ideas2it.service.impl;

import com.ideas2it.dao.UserDao;
import com.ideas2it.dao.impl.UserDaoImpl;
import com.ideas2it.model.Employee;
import com.ideas2it.model.Trainee;
import com.ideas2it.model.Trainer;
import com.ideas2it.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;



@Component
public class UserServiceImpl<T extends Employee> implements UserService {


    @Autowired
    UserDao userDao;

    public void register(Employee user) {
        if (user instanceof Trainer) {
            userDao.register((Trainer) user);
        } else {
            userDao.register((Trainee) user);
        }
    }

    @Override
    public List<Trainer> getTrainers() {

        return userDao.getTrainers();
    }

    public List<Trainee> getTrainees() {

        return userDao.getTrainees();
    }


    public void update(Employee user) {
        if (user instanceof Trainer) {
            Trainer trainer = userDao.retrieveTrainerById(user.getEmployeeId());
            trainer.setEmployeePhoneNumber(user.getEmployeePhoneNumber());
            userDao.update(trainer);
        } else {
            Trainee trainee = userDao.retrieveTraineeById(user.getEmployeeId());
            trainee.setEmployeePhoneNumber(user.getEmployeePhoneNumber());
            userDao.update(trainee);
        }
    }

    public Trainer getTrainerById(String employeeId){
        return userDao.retrieveTrainerById(employeeId);
    }
    public Trainee getTraineeById(String employeeId) {
        return  userDao.retrieveTraineeById(employeeId);
    }
}