package com.ideas2it.model;

import org.springframework.stereotype.Component;

import javax.persistence.*;


@NamedQueries(
        {
                @NamedQuery(
                        name = "findTrainee",
                        query = "from Trainee"
                ),
                @NamedQuery(
                        name  = "findTraineeById",
                        query = "from Trainee e where e.employeeId = :employeeId"
                )

        }
)

@Entity
@Table(name="Trainee")

public class Trainee extends Employee {
    @Id
    @GeneratedValue
    private int id;

}
