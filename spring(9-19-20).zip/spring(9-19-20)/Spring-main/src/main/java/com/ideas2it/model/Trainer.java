package com.ideas2it.model;

import org.springframework.stereotype.Component;

import javax.persistence.*;

@NamedQueries(
        {
                @NamedQuery(
                        name = "findTrainer",
                        query = "from Trainer"
                ),
                @NamedQuery(
                        name  = "findTrainerById",
                        query = "from Trainer e where e.employeeId = :employeeId"
                )
        }
)

@Entity
@Table(name="Trainer")

public class Trainer extends Employee {

    @Id
    @GeneratedValue
    private int id;


}
